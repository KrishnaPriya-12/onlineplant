package com.cg.onlineplantnursery.dto;

import lombok.Data;

@Data
public class ExceptionDTOResponse {
	
	private String errorMsg;
	private String dateTime;

}
