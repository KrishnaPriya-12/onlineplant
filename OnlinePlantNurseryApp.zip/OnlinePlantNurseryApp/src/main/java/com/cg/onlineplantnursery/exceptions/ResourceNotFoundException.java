package com.cg.onlineplantnursery.exceptions;

public class ResourceNotFoundException {

}
