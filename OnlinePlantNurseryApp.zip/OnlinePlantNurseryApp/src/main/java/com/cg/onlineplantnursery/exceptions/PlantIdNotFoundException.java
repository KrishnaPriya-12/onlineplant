package com.cg.onlineplantnursery.exceptions;

public class PlantIdNotFoundException extends Exception {
	public PlantIdNotFoundException() {

	}

	public PlantIdNotFoundException(String message) {
		super(message);
	}

}
