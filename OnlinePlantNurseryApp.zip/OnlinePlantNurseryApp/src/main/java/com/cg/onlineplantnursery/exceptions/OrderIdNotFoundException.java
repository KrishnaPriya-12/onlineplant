package com.cg.onlineplantnursery.exceptions;

public class OrderIdNotFoundException extends Exception {
	
	public OrderIdNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	public OrderIdNotFoundException(String msg) {
		super(msg);
	}
	

}
