package com.cg.onlineplantnursery.exceptions;

public class PlanterIdNotFoundException extends Exception {
	public PlanterIdNotFoundException() {

	}

	public PlanterIdNotFoundException(String message) {
		super(message);
	}

}
