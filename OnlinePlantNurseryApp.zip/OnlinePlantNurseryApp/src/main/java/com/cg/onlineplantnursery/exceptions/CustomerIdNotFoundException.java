package com.cg.onlineplantnursery.exceptions;

public class CustomerIdNotFoundException extends Exception {
	
	public CustomerIdNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public CustomerIdNotFoundException(String msg) {
		super(msg);
	}

}
