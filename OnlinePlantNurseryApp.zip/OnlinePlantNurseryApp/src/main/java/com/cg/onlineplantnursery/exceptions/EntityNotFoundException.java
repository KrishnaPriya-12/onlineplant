package com.cg.onlineplantnursery.exceptions;

public class EntityNotFoundException extends Exception {

	public EntityNotFoundException() {
	}

	

	public EntityNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
