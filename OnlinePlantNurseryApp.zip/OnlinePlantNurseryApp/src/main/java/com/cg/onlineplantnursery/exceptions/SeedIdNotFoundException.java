package com.cg.onlineplantnursery.exceptions;

public class SeedIdNotFoundException extends Exception {
	public SeedIdNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public SeedIdNotFoundException(String msg) {
		super(msg);
	}

}
